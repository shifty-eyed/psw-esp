#ifndef KEYBOARD_H
#define KEYBOARD_H

#include "lvgl.h"

lv_obj_t * lv_my_keyboard_create(lv_obj_t * parent);

#endif // KEYBOARD_H