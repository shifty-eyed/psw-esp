| Supported Targets | ESP32-S3 |
| ----------------- | -------- |

# ESP-IDF BT/BLE HID Device "Secure keyboard"

## How to Use Example
TBD


# TODO

## Pair device dialog
    fix pairing known device error hadnling

## Pop up menus:
    device tab: 2 btn visible: conn/dis, (...) -> create, delete, set device name
    password tab: 2 btn visible: apply, (...) -> create, delete, edit


## Refactoring
    merge the logic for registry

## Misc
    settings:
    add brightness control
    experiment with loading and deleting lvgl objects instead of visibilty
